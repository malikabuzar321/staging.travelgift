<?php
add_action('wp_ajax_gctcf_hotel_search', 'gctcf_hotel_search');
add_action('wp_ajax_nopriv_gctcf_hotel_search', 'gctcf_hotel_search');

function gctcf_hotel_search()
{
	global $wpdb;
	$html = '';
	$hotel_region_list = sanitize_text_field($_POST['hotel_region_list']);
	$hotel_region_aql = "SELECT region_id, region_name, country_name FROM `hotel_region` WHERE `region_name` LIKE '%$hotel_region_list%' ORDER BY `id` DESC LIMIT 0,10";
	$hotel_region_array = array();
	$hotel_region_array = $wpdb->get_results($hotel_region_aql);

	$travellanda_results = array();
	$stuba_results = array();

	require_once GCTCF_PATH . '/includes/Travellanda.class.php';

	$travellanda_settings = get_travellanda_api_config();

	$travellanda = new Travellanda();
	$travellanda->setUsername($travellanda_settings['user']);
	$travellanda->setPassword($travellanda_settings['pass']);
	$travellanda->setMode($travellanda_settings['mode']);

	$travellanda_results = $travellanda->citySearch($hotel_region_list);
	//pre($travellanda_results, 1);
	$merged_results = array();

	foreach ($hotel_region_array as $hotel_region_name) {
		$code = strtolower(trim($hotel_region_name->country_name)) . '_' . strtolower(trim($hotel_region_name->region_name));
		$stuba_results[$code]['country_name'] = trim($hotel_region_name->country_name);
		$stuba_results[$code]['country_code'] = '';
		$stuba_results[$code]['city_name'] = trim($hotel_region_name->region_name);
		$stuba_results[$code]['ids'][] = trim($hotel_region_name->region_id);
	}

	foreach ($travellanda_results as $code => $result) {
		$merged_results[$code]['country_code'] = $result['country_code'];
		$merged_results[$code]['country_name'] = $result['country_name'];
		$merged_results[$code]['city_name'] = $result['city_name'];
		$merged_results[$code]['ids']['travellanda'] = $result['ids'];
		$merged_results[$code]['ids']['stuba'] = array();
	}

	foreach ($stuba_results as $code => $result) {
		if (strpos($code, 'uk -') !== false) {
			$exploded = explode('_', $code);
			foreach ($merged_results as $merged_code => $merged_result) {
				$merged_exploded = explode('_', $merged_code);
				//compare city name
				if ( (string) $exploded[1] == (string) $merged_exploded[1] && (string)$merged_exploded[0] == 'uk' ) {
					$merged_results[$code] = array(
						'country_code' => $merged_result['country_code'],
						'country_name' => $merged_result['contry_name'],
						'city_name' => $merged_result['city_name'],
						'ids' => array(
							'travellanda' => $merged_result['ids']['travellanda'],
							'stuba' => array(),
						)
					);
					unset($merged_results[$merged_code]);
				}
			}
		}
		$merged_results[$code]['country_code'] = (isset($merged_results[$code]['country_code'])) ? $merged_results[$code]['country_code'] : $result['country_code'];
		$merged_results[$code]['country_name'] = $result['country_name'];
		$merged_results[$code]['city_name'] = $result['city_name'];
		$merged_results[$code]['ids']['travellanda'] = (isset($merged_results[$code]['ids']['travellanda'])) ? $merged_results[$code]['ids']['travellanda'] : array();
		$merged_results[$code]['ids']['stuba'] = $result['ids'];
	}

	$html .= '<ul id="hotel_result_ul">';
	$count = 1;

	foreach ($merged_results as $code => $merged_result) {
		$html .= '<li data-country-code="' . strtolower($merged_result['country_code']) . '" data-region-ids="' . htmlentities(json_encode($merged_result['ids'])) . '" data-value="' . $merged_result['city_name'] . '--' . $merged_result['country_name'] . '" id="region-id-id-' . $count . '" class="region_id_id" value="' . $code . '">' . $merged_result['city_name'] . '--' . $merged_result['country_name'] . '<input type="hidden" name="hotel__region__code" id="hotel--region--code" class="" value="' . htmlentities(json_encode($merged_result['ids'])) . '" /><input type="hidden" name="hotel__region__name" id="hotel__region__name" class="region-id-id-' . $count . '-region_name" value="' . $merged_result['city_name'] . '" /><input type="hidden" name="hotel_region_country" id="hotel_region_country" class="region-id-id-' . $count . '-country" value="' . $merged_result['country_name'] . '" /></li>';

		$count++;
	}
	$html .= '</ul>';


	echo $html;
	exit();
}

add_action('wp_ajax_gctc_fetch_tour', 'gctc_fetch_tour');
add_action('wp_ajax_nopriv_gctc_fetch_tour', 'gctc_fetch_tour');
function gctc_fetch_tour()
{
	$errors = array(
		'not_found' => 'Tour not found',
	);
	if (!isset($_POST['tour_id']) || $_POST['tour_id'] <= 0) {
		echo json_encode(array('res' => 'error', 'message' => __('No tour found', 'gctcf')));
		exit();
	}
	$post_id = $_POST['tour_id'];
	$tour = get_post($post_id);
	if (empty($tour)) {
		echo json_encode(array('res' => 'error', 'message' => __('No tour found', 'gctcf')));
		exit();
	}
	$img = GCTCF_URL . 'public/images/hotel-placeholder-img.png';
	if (get_the_post_thumbnail_url($post_id)) {
		$img = get_the_post_thumbnail_url($post_id);
	}

	$data = array(
		'res' => 'suucess',
		'tour_id' => $tour->ID,
		'post_content' => apply_filters('the_content', $tour->post_content),
		'post_title' => $tour->post_title,
		'images' => $img,
		'sub_heading' => get_post_meta($tour->ID, 'gc4t_duration', true),
	);
	echo json_encode($data);
	exit();
}

add_action('wp_ajax_gc4t_submit_tour_enquiry', 'gc4t_submit_tour_enquiry');
add_action('wp_ajax_nopriv_gc4t_submit_tour_enquiry', 'gc4t_submit_tour_enquiry');

function gc4t_submit_tour_enquiry()
{
	$errors = array();

	$tour_id = sanitize_text_field($_POST['tour_id']);
	$tour_name = sanitize_text_field($_POST['tour_name']);
	$tour_email = sanitize_text_field($_POST['tour_email']);
	$tour_contact_number = sanitize_text_field($_POST['tour_contact_number']);
	$tour_booking_date = sanitize_text_field($_POST['tour_booking_date']);
	$tour_booking_date_alt = sanitize_text_field($_POST['tour_booking_date_alt']);
	$tour_adults = sanitize_text_field($_POST['tour_adults']);
	$tour_children = sanitize_text_field($_POST['tour_children']);
	$tour_adults = (is_numeric($tour_adults)) ? $tour_adults : 0;
	$tour_children = (is_numeric($tour_children)) ? $tour_children : 0;
	$tour_message = esc_textarea($_POST['tour_message']);

	if (!is_numeric($tour_id)) {
		$errors['tour_id'] = 'Please select a valid tour';
	}
	if (empty($tour_name)) {
		$errors['tour_name'] = 'Please enter your name';
	}
	if (!filter_var($tour_email, FILTER_VALIDATE_EMAIL)) {
		$errors['tour_email'] = 'Please enter a valid email';
	}
	if (empty($tour_contact_number)) {
		$errors['tour_contact_number'] = 'Please enter a contact number';
	}
	if (empty($tour_booking_date)) {
		$errors['tour_booking_date'] = 'Please select a booking date';
	}
	if (empty($tour_booking_date_alt)) {
		$errors['tour_booking_date_alt'] = 'Please select an alternative booking date';
	}
	if ($tour_adults == 0 && $tour_children == 0) {
		$errors['tour_adults'] = 'Please enter number of people to book for';
	}

	if (empty($tour_message)) {
		$errors['tour_message'] = 'Please enter a message';
	}

	if (!empty($errors)) {

		echo json_encode(array('res' => 'error', 'data' => $errors));
		exit();
	}

	$tour = get_post($tour_id);
	$link = get_permalink($tour->ID);
	$message = "\r\n\r\n";
	$message .= "Tour: {$tour->post_title}\r\n";
	$message .= "Link: $link\r\n";
	$message .= "Name: $tour_name\r\n";
	$message .= "Email: $tour_email\r\n";
	$message .= "Contact Number: $tour_contact_number\r\n";
	$message .= "Booking Date: $tour_booking_date\r\n";
	$message .= "Booking Date (Alt.): $tour_booking_date_alt\r\n";
	$message .= "Adults: $tour_adults\r\n";
	$message .= "Children: $tour_children\r\n";
	$message .= "Message:\r\n";
	$message .= $tour_message;
	$email_content .= '<!DOCTYPE html>
						<html>
						<head>
						<title>Booking Email</title>
						<meta charset="UTF-8">
						<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1">
						</head>
						<body class="booking-email-block" style="padding: 0px; margin: 0px;">
						<table width="100%" style="max-width: 1200px; margin: 0 auto; padding: 15px; font-family:Arial, Helvetica, sans-serif; border:1px solid #061d2f; color:#061d2f" cellpadding="0" cellspacing="0">
						<tr>
							<td colspan="5" style="padding-top:0px;"><h2 style="font-size: 16px; font-weight: 700;background-color: #fad38f; padding: 10px 15px; text-align: left; margin: 0px;font-family: sans-serif; color: #061d2f; text-transform: uppercase;">A tour enquiry was submitted on Giftcards4travel.co.uk</h2></td>
						</tr>
						<tr>
							<td width="25%" style="font-size: 16px;font-family:Arial, Helvetica, sans-serif; text-align: left; padding:5px; padding-top: 20px;"><strong>Tour</strong></td>
							<td width="25%" style="font-size: 16px;font-family:Arial, Helvetica, sans-serif; text-align: left;  padding:5px;padding-top: 20px;"><strong>Link</strong></td>
							<td width="25%" style="font-size: 16px;font-family:Arial, Helvetica, sans-serif; text-align: left; padding:5px; padding-top: 20px;"> <strong>Name</strong></td>
							<td width="25%" style="font-size: 16px;font-family:Arial, Helvetica, sans-serif; text-align: left; padding:5px; padding-top: 20px;"> <strong>Email</strong></td>
						</tr>
						<tr>
							<td align="top" style="font-size: 14px;font-family: sans-serif; color: #061d2f; padding:5px;">' . $tour->post_title . '</td>
							<td align="top" style="font-size: 14px;font-family: sans-serif; color: #061d2f; padding:5px;">' . $link . '</td>
							<td align="top" style="font-size: 14px;font-family: sans-serif; color: #061d2f; padding:5px;">' . $tour_name . '</td>
							<td align="top" style="font-size: 14px;font-family: sans-serif; color: #061d2f; padding:5px;">' . $tour_email . '</td>
						</tr>
						<tr>
							<td width="25%" style="font-size: 16px;font-family:Arial, Helvetica, sans-serif; text-align: left; padding:5px; padding-top: 20px;"> <strong>Contact Number</strong></td>
							<td width="25%" style="font-size: 16px;font-family:Arial, Helvetica, sans-serif; text-align: left; padding:5px; padding-top: 20px;"><strong>Booking Date</strong></td>
							<td width="25%" style="font-size: 16px;font-family:Arial, Helvetica, sans-serif; text-align: left; padding:5px; padding-top: 20px;"><strong>Booking Date (Alt.)</strong></td>
							<td width="25%" style="font-size: 16px;font-family:Arial, Helvetica, sans-serif; text-align: left; padding:5px; padding-top: 20px;"><strong>Adults</strong></td>
						</tr>
						<tr>
							<td style="font-size: 14px;font-family: sans-serif; color: #061d2f; padding:5px;">' . $tour_contact_number . '</td>
							<td style="font-size: 14px;font-family: sans-serif; color: #061d2f; padding:5px;">' . $tour_booking_date . '</td>
							<td style="font-size: 14px;font-family: sans-serif; color: #061d2f; padding:5px;">' . $tour_booking_date_alt . '</td>
							<td style="font-size: 14px;font-family: sans-serif; color: #061d2f; padding:5px;">' . $tour_adults . '</td>
						</tr>
						<tr>
							<td width="25%" style="font-size: 16px;font-family:Arial, Helvetica, sans-serif; text-align: left; padding:5px; padding-top: 20px;"> <strong>Children</strong></td>
						</tr>
						<tr>
							<td style="font-size: 14px;font-family: sans-serif; color: #061d2f; padding:5px;">' . $tour_children . '</td>
						</tr>
						<tr>
							<td colspan="5" style="font-size: 16px;font-family:Arial, Helvetica, sans-serif; text-align: left; padding:5px;padding-top: 20px;"><strong>Message:-</strong></td>
						</tr>
						<tr>
							<td colspan="5" style="font-size: 14px;font-family: sans-serif; color: #061d2f; padding:5px;">' . $tour_message . '</td>
						</tr>
						</table>
						</body>
						</html>';
	$headers = array('Content-Type: text/html; charset=UTF-8');
	wp_mail('bookings@giftcards4travel.co.uk', 'New Tour Enquiry Submitted', $email_content, $headers);
	// wp_mail('developersuseonly@gmail.com', 'New Tour Enquiry Submitted', $email_content, $headers);

	echo json_encode(array('res' => 'success', 'message' => 'Thank you for your enquiry'));
	exit();
}

//Hotel quick view ajax
add_action('wp_ajax_gctc_hotel_quick_view', 'gctc_hotel_quick_view');
add_action('wp_ajax_nopriv_gctc_hotel_quick_view', 'gctc_hotel_quick_view');

function gctc_hotel_quick_view()
{

	if (!isset($_POST['hotel__id']) || $_POST['hotel__id'] <= 0 || !isset($_POST['feed']) || empty($_POST['feed'])) {
		echo json_encode(array('res' => 'error', 'message' => __('No hotel found', 'gctcf')));
		exit();
	}
	$hotel_id = $_POST['hotel__id'];
	$feed = $_POST['feed'];
	$html = '';
	ob_start();
	include_once(GCTCF_PATH . 'public/partials/gctc-hotel-quick-view.php');
	$html .= ob_get_clean();

	echo json_encode(array('res' => 'success', 'html' => $html));
	exit();
}

//coupon search ajax
add_action('wp_ajax_gctc_coupon_search', 'gctc_coupon_search');
add_action('wp_ajax_nopriv_gctc_coupon_search', 'gctc_coupon_search');

function gctc_coupon_search()
{

	global $wpdb;
	$amount = 0;
	if (isset($_POST['quote_id'])) {
		$quote_id = sanitize_text_field($_POST['quote_id']);
		$post_id = sanitize_text_field($_POST['post_id']);
		update_post_meta($post_id, '_gctcf_coupon_checked', '');
		if (isset($_POST['feed_type'])) {

			if ($_POST['feed_type'] == 'stuba') {
				$wpdb->query(
					"UPDATE user_login_table SET discount_coupon_code = '' WHERE hotel_quote_id = '$quote_id'"
				);
			}
			if ($_POST['feed_type'] == 'travellanda') {
				update_post_meta($quote_id, 'gc4t_discount_code', '');
			}
		}

		if (!empty($_POST['coupon_code_search'])) {
			$coupon_code = sanitize_text_field($_POST['coupon_code_search']);
			update_post_meta($post_id, '_gctcf_coupon_checked', $coupon_code);
			$discount_type = 'amount';
			$coupon_wp = new WC_Coupon($coupon_code);
			if ($coupon_wp->get_discount_type() == 'percent') {
				$discount_type = 'percent';
			}
			$amount = $coupon_wp->get_amount();
			if (!$amount) {
				$physical_vouchers = get_posts(array(
					'post_type' => 'gc4t_store_voucher',
					'post_status' => 'private',
					'posts_per_page' => 1,
					'meta_query' => array(
						array(
							'key' => 'gc4t_voucher_status',
							'value' => 'active',
						),
						array(
							'key' => 'gc4t_voucher_code',
							'value' => $coupon_code,
						),
					)
				));
				$booking_detail = get_post_meta($post_id, 'gc4t_booking_id', true);
				update_post_meta($post_id, '_gctcf_booking_amount', $_POST['total_price']);
				if (isset($physical_vouchers[0])) {
					$amount = get_post_meta($physical_vouchers[0]->ID, 'gc4t_voucher_amount_remaining', true);
					if ($booking_detail == 0) {
						update_post_meta($post_id, '_gctcf_coupon_amount', $amount);
						update_post_meta($post_id, '_gctcf_coupon_code', $coupon_code);
					}
				} else {
					if ($booking_detail == 0) {
						update_post_meta($post_id, '_gctcf_coupon_amount', '');
						update_post_meta($post_id, '_gctcf_coupon_code', '');
					}
				}
				$total_price = sanitize_text_field($_POST['total_price']);
				$total_price = ($total_price) ? $total_price : 0;
				if ($total_price) {
					$difference = $total_price - $amount;
					if ($difference < 0) {
						$amount = $total_price - 1;
					}
				}
			}
			if ($amount) {
				if (isset($_POST['quote_id'])) {
					$quote_id = sanitize_text_field($_POST['quote_id']);
					if (isset($_POST['feed_type'])) {
						if ($_POST['feed_type'] == 'stuba') {
							$wpdb->query(
								"UPDATE user_login_table SET discount_coupon_code = '$coupon_code' WHERE hotel_quote_id = '$quote_id'"
							);
						}

						if ($_POST['feed_type'] == 'travellanda') {
							update_post_meta($post_id, 'gc4t_discount_code', $coupon_code);
						}
					}
				}
			}
		}
		if ($discount_type == 'percent') {
			$total_price = sanitize_text_field($_POST['total_price']);
			$total_price = ($total_price) ? $total_price : 0;
			if ($total_price) {
				$discount_amount = $total_price / 100 * $amount;
				$amount = sprintf('%01.2f', $discount_amount);
			}
		}
		echo $amount;
	}
	exit;
}


//  Ajax transfer departure location search ajax
add_action('wp_ajax_gctcf_hotel_search_transfer', 'gctcf_hotel_search_transfer');
add_action('wp_ajax_nopriv_gctcf_hotel_search_transfer', 'gctcf_hotel_search_transfer');

function gctcf_hotel_search_transfer()
{
	$hotel_list = $_POST['hotel_name_list'];
	$location_type = $_POST['location_type'];
	//echo $hotel_region_list='kol';
	global $wpdb;
	if ($location_type == 'AP') {

		$hotel_name_aql = "SELECT * FROM `transfers_for_hotel_list` WHERE `location_type`='RT' AND `location_name` LIKE '%$hotel_list%' ORDER BY `id` DESC LIMIT 0,10";
	} elseif ($location_type == 'RT') {

		$hotel_name_aql = "SELECT * FROM `transfers_for_hotel_list` WHERE `location_type`='AP' AND `location_name` LIKE '%$hotel_list%' ORDER BY `id` DESC LIMIT 0,10";
	} else {

		$hotel_name_aql = "SELECT * FROM `transfers_for_hotel_list` WHERE `location_name` LIKE '%$hotel_list%' ORDER BY `id` DESC LIMIT 0,15";
	}

	$hotel_name_array = $wpdb->get_results($hotel_name_aql);
	ob_start();
?>
	<ul id="hotel_result_ul">
		<?php
		$count = 1;
		if ($hotel_name_array) {
			foreach ($hotel_name_array as $hotel_location_name) {
		?>
				<li style="font-size: 14px;cursor: pointer;padding: 5px;border-bottom: 1px solid #fff;list-style:none;" data-value="<?php echo $hotel_location_name->location_name; ?>" id="city-name-by-name_<?php echo $count; ?>" class="hotel_id_id"> <?php echo $hotel_location_name->location_code . '-' . $hotel_location_name->location_name; ?>
					<input type="hidden" value="<?php echo $hotel_location_name->location_code; ?>" name="city_name_by_hidden" id="hotel_code_name" class="city-name-by-name_<?php echo $count; ?>_iata" />
					<input type="hidden" value="<?php echo $hotel_location_name->location_latitude; ?>" name="hotel_name_by_latitude" id="hotel_latitude" class="city-name-by-name_<?php echo $count; ?>_latitude" />
					<input type="hidden" value="<?php echo $hotel_location_name->location_longitude; ?>" name="hotel_name_by_longitude" id="hotel_longitude" class="city-name-by-name_<?php echo $count; ?>_longitude" />
					<input type="hidden" value="<?php echo $hotel_location_name->location_type; ?>" name="hotel_location_by_type" id="hotel_location_by_type" class="city-name-by-name_<?php echo $count; ?>_ltype" />
				</li>
			<?php
				$count++;
			}
		} else {
			?>
			<li style="font-size: 14px;cursor: pointer;padding: 5px;border-bottom: 1px solid #fff;list-style:none;" class="hotel_id_id">
				<?php esc_attr_e('No result found!', 'gctcf'); ?>
			</li>
		<?php
		}
		?>
	</ul>
<?php
	$data = ob_get_clean();
	wp_send_json_success($data);
	// echo $data;
}


//  Ajax transfer arrival location search ajax
add_action('wp_ajax_gctcf_hotel_search_arrival', 'gctcf_hotel_search_arrival');
add_action('wp_ajax_nopriv_gctcf_hotel_search_arrival', 'gctcf_hotel_search_arrival');

function gctcf_hotel_search_arrival()
{
	$hotel_list = $_POST['hotel_name_list'];
	$location_type = $_POST['location_type'];
	//echo $hotel_region_list='kol';
	global $wpdb;
	if ($location_type == 'AP') {

		$hotel_name_aql = "SELECT * FROM `transfers_for_hotel_list` WHERE `location_name` LIKE '%$hotel_list%' ORDER BY `id` DESC LIMIT 0,15";
		//$hotel_name_aql="SELECT * FROM `transfers_for_hotel_list` WHERE `location_type`='RT' AND `location_name` LIKE '%$hotel_list%' ORDER BY `id` DESC LIMIT 0,10";

	} elseif ($location_type == 'RT') {

		$hotel_name_aql = "SELECT * FROM `transfers_for_hotel_list` WHERE `location_type`='AP' AND `location_name` LIKE '%$hotel_list%' ORDER BY `id` DESC LIMIT 0,10";
	} else {

		$hotel_name_aql = "SELECT * FROM `transfers_for_hotel_list` WHERE `location_name` LIKE '%$hotel_list%' ORDER BY `id` DESC LIMIT 0,15";
	}

	$hotel_name_array = $wpdb->get_results($hotel_name_aql);
	ob_start();
?>
	<ul id="hotel_result_ul">
		<?php
		$count = 1;
		if ($hotel_name_array) {
			foreach ($hotel_name_array as $hotel_location_name) {
		?>
				<li style="font-size: 14px;
		cursor: pointer;
		padding: 5px;
		border-bottom: 1px solid #fff;
		list-style:none;" data-value="<?php echo $hotel_location_name->location_name; ?>" id="location-by-hotel_<?php echo $count; ?>" class="hotel_id_by_name"> <?php echo $hotel_location_name->location_code . '-' . $hotel_location_name->location_name; ?>
					<input type="hidden" value="<?php echo $hotel_location_name->location_code; ?>" name="city_name_by_hidden" id="hotel_code_name" class="location-by-hotel_<?php echo $count; ?>_iata" />

					<input type="hidden" value="<?php echo $hotel_location_name->location_latitude; ?>" name="hotel_name_by_latitude" id="hotel_latitude" class="location-by-hotel_<?php echo $count; ?>_latitude" />

					<input type="hidden" value="<?php echo $hotel_location_name->location_longitude; ?>" name="hotel_name_by_longitude" id="hotel_longitude" class="location-by-hotel_<?php echo $count; ?>_longitude" />

					<input type="hidden" value="<?php echo $hotel_location_name->location_type; ?>" name="hotel_location_by_type" id="hotel_location_by_type" class="location-by-hotel_<?php echo $count; ?>_ltype" />

				</li>
			<?php
				$count++;
			}
		} else {
			?>
			<li style="font-size: 14px;cursor: pointer;padding: 5px;border-bottom: 1px solid #fff;list-style:none;" class="hotel_id_id">
				<?php esc_attr_e('No result found!', 'gctcf'); ?>
			</li>
		<?php
		}
		?>
	</ul>
<?php
	$data = ob_get_clean();
	wp_send_json_success($data);
	// echo $data;
}

//  Ajax for country search
add_action('wp_ajax_gctcf_get_countries', 'gctcf_get_countries');
add_action('wp_ajax_nopriv_gctcf_get_countries', 'gctcf_get_countries');
function gctcf_get_countries()
{
	$cars_country_list = $_POST['cars_country_name'];
	global $wpdb;
	$html = '';
	$car_country_aql = "SELECT * FROM `countries` WHERE `name` LIKE '%$cars_country_list%' ORDER BY `id` DESC LIMIT 0,20";
	$car_country_array = $wpdb->get_results($car_country_aql);
	if ($car_country_array) {
		$html .= '<ul id="country_result_ul">';

		foreach ($car_country_array as $car_country_name) {
			$html .= '<li data-value="' . $car_country_name->sortname . '" class="country_id_id">' . $car_country_name->name . '<input type="hidden" value="' . $car_country_name->sortname . '" name="city_name_by_hidden" id="country-chort-name" /></li>';
		}
		$html .= '</ul>';
	}
	echo $html;
	exit();
}

//coupon search ajax
add_action('wp_ajax_gctc_transfer_coupon_search', 'gctc_transfer_coupon_search');
add_action('wp_ajax_nopriv_gctc_transfer_coupon_search', 'gctc_transfer_coupon_search');

function gctc_transfer_coupon_search()
{


	global $wpdb;
	$amount = 0;
	if (!empty($_POST['coupon_code_search'])) {
		$coupon_code = sanitize_text_field($_POST['coupon_code_search']);
		$coupon_wp = new WC_Coupon($coupon_code);

		$amount = $coupon_wp->get_amount();
		if (!$amount) {
			$physical_vouchers = get_posts(array(
				'post_type' => 'gc4t_store_voucher',
				'post_status' => 'private',
				'posts_per_page' => 1,
				'meta_query' => array(
					array(
						'key' => 'gc4t_voucher_status',
						'value' => 'active',
					),
					array(
						'key' => 'gc4t_voucher_code',
						'value' => $coupon_code,
					),
				)
			));
			if (isset($physical_vouchers[0])) {
				$amount = get_post_meta($physical_vouchers[0]->ID, 'gc4t_voucher_amount_remaining', true);
			}
			$total_price = sanitize_text_field($_POST['total_price']);
			$total_price = ($total_price) ? $total_price : 0;
			if ($total_price) {
				$difference = $total_price - $amount;
				if ($difference < 0) {
					$amount = $total_price - 1;
				}
			}
		}
	}
	echo $amount;
	exit;
}

//attractions search ajax
add_action('wp_ajax_gctcf_attractions_search', 'gctcf_attractions_search');
add_action('wp_ajax_nopriv_gctcf_attractions_search', 'gctcf_attractions_search');

function gctcf_attractions_search()
{

	if (!empty($_POST['title'])) {
		$title = $_POST['title'];
		$response = wp_remote_get(
			'https://phx.dosomethingdifferent.com/api/products?title=' . $title,
			array(
				'timeout'     => 120,
			)
		);

		$res = wp_remote_retrieve_body($response);
		$data = json_decode($res, true);

		if (!empty($data['data'])) {
			$html = '<ul>';
			foreach ($data['data'] as $result) {
				$html .= '<li><a target="_blank" href="' . site_url('attraction-details?id=') . $result['id'] . '">' . $result['title'] . '</a></li>';
			}
			$html .= '</ul>';
		} else {
			$html = '<div>No record found.</div>';
		}

		echo $html;
		exit;
	}
}

//attractions search by destination ajax
add_action('wp_ajax_gctcf_attractions_search_by_destination', 'gctcf_attractions_search_by_destination');
add_action('wp_ajax_nopriv_gctcf_attractions_search_by_destination', 'gctcf_attractions_search_by_destination');

function gctcf_attractions_search_by_destination()
{

	$destinations = isset($_POST['dest']) ? $_POST['dest'] : array();
	$tags = isset($_POST['tags']) ? $_POST['tags'] : array();
	$Product = isset($_POST['Product']) ? $_POST['Product'] : '';

	$attraction_settings = get_option('attraction_api_option');
	$attraction_api_url = $attraction_settings['attraction_api_url'];
	$attraction_api_url = rtrim($attraction_api_url, '/');
	$attraction_api_user = $attraction_settings['attraction_api_username'];
	$attraction_api_pass = $attraction_settings['attraction_api_password'];

	$allResponse = array();


	//echo $attraction_api_url.'/products?dest='.implode(',', $destinations);
	if (!empty($destinations)) {
		$response1 = wp_remote_get(
			$attraction_api_url . '/products?dest=' . implode(',', $destinations) . '&view=extended',
			array(
				'timeout'     => 120,
			)
		);
		$res1 = wp_remote_retrieve_body($response1);
		$data1 = json_decode($res1, true);
	}

	//echo $attraction_api_url.'/products?tags='.implode(',', $tags);
	if (!empty($tags)) {
		$response2 =  wp_remote_get(
			$attraction_api_url . '/products?tags=' . implode(',', $tags) . '&view=extended',
			array(
				'timeout'     => 120,
			)
		);

		$res2 = wp_remote_retrieve_body($response2);
		$data2 = json_decode($res2, true);
	}

	if (!empty($data1['data']) && !empty($data2['data'])) {
		$allResponse = array_merge($data1['data'], $data2['data']);
	} else if (!empty($data1['data'])) {
		$allResponse = $data1['data'];
	} else if (!empty($data2['data'])) {
		$allResponse = $data2['data'];
	}


	$html .= '<div class="gctcf-loader attraction-loader" style="display: none;"><div class="gctcf-loader-wrap"><img src="' . site_url() . '/wp-content/plugins/gctcf/public/images/loader.gif"><div class="loader-message"><p>The result will appear within a few seconds.</p></div></div></div>';
	if (!empty($allResponse)) {

		foreach ($allResponse as $result) {
			$html .= '<div class="tour-view-row">
      					<div class="list-image"> <a href="#"> <img src="' . $result['img_sml'] . '" alt="img"></a> </div>
  						<div class="img-desc">
        					<div class="img-heading">
          						<h2> <a href="' . site_url('attraction-details?id=') . $result['id'] . '"> ' . $result['title'] . '</a></h2>
        					</div>
        					<div class="short-des">';
			if ($result['price_from_child'] != '') {
				$html .= '<p>' . $result['desc_short'] . '</p>';
			}
			$html .= '</div>
        					<div class="price-list">';
			if ($result['price_from_child'] != '') {
				$html .= '<p> child from <span>£ ' . $result['price_from_child'] . '</span> </p>';
			}
			if ($result['price_from_adult'] != '') {
				$html .= '<p> adult from <span>£ ' . $result['price_from_adult'] . '</span> </p>';
			}

			$html .= '</div>
        					<p class="loction"> ' . $result['dest'] . ' </p>
      					</div>
    				</div>';
		}
	} else {
		$html = '<div class="no-records-msg">No record found.</div>';
	}

	echo $html;
	exit;
}

add_action('wp_ajax_gctcf_attractions_dateid', 'gctcf_attractions_dateid');
add_action('wp_ajax_nopriv_gctcf_attractions_dateid', 'gctcf_attractions_dateid');

function gctcf_attractions_dateid()
{
	$html = '';
	$date1 = isset($_POST['date']) ? $_POST['date'] : '';
	$date_create = date_create($date1);
	$date = date_format($date_create, "Y-m-d");
	$time = isset($_POST['time']) ? $_POST['time'] : '';
	$product_id = isset($_POST['product_id']) ? $_POST['product_id'] : '';
	$datefrom = isset($_POST['datefrom']) ? $_POST['datefrom'] : '';
	$dateto = isset($_POST['dateto']) ? $_POST['dateto'] : '';

	if (!empty($product_id) && !empty($datefrom) && !empty($dateto) && !empty($date1)) {

		$apiUrl = 'https://phx.dosomethingdifferent.com/api/products/' . $product_id . '?date_from=' . $datefrom . '&date_to=' . $dateto;

		$response = wp_remote_get($apiUrl, array(
			'timeout'     => 120,
		));

		$responseBody = wp_remote_retrieve_body($response);
		$result = json_decode($responseBody, true);

		foreach ($result['tickets'] as $value) {

			foreach ($value['availability'] as $value1) {

				if (!empty($time)) {
					if ($value1['date'] == $date && $value1['time'] == $time) {
						$dateid = $value1['date_id'];
					}
				} else {
					if ($value1['date'] == $date) {
						$dateid = $value1['date_id'];
					}
				}
			}
		}
		if ($dateid) {
			wp_send_json_success($dateid);
		} else {
			wp_send_json_error('Booking not avialble on this time and date');
		}
	}
	exit;
}

add_action('wp_ajax_gctcf_attractions_avilabletime', 'gctcf_attractions_avilabletime');
add_action('wp_ajax_nopriv_gctcf_attractions_avilabletime', 'gctcf_attractions_avilabletime');

function gctcf_attractions_avilabletime()
{
	$html = '';

	$date1 = isset($_POST['date']) ? $_POST['date'] : '';

	$date_create = date_create($date1);
	$date = date_format($date_create, "Y-m-d");

	$product_id = isset($_POST['product_id']) ? $_POST['product_id'] : '';
	$datefrom = isset($_POST['datefrom']) ? $_POST['datefrom'] : '';
	$dateto = isset($_POST['dateto']) ? $_POST['dateto'] : '';

	$timeArr = array();

	if (!empty($product_id) && !empty($datefrom) && !empty($dateto) && !empty($date1)) {

		$apiUrl = 'https://phx.dosomethingdifferent.com/api/products/' . $product_id . '?date_from=' . $datefrom . '&date_to=' . $dateto;

		$response = wp_remote_get($apiUrl, array(
			'timeout'     => 120,
		));

		$responseBody = wp_remote_retrieve_body($response);
		$result = json_decode($responseBody, true);

		foreach ($result['tickets'] as $value) {

			foreach ($value['availability'] as $value1) {
				if ($value1['date'] == $date) {
					$timeArr[] = $value1['time'];
				}
			}
		}
	}

	if (!empty($timeArr)) {
		foreach (array_unique($timeArr) as $value1) {
			$html .= '<option value="' . $value1 . '">' . $value1 . '</option>';
		}
		wp_send_json_success(array('html' => $html, 'time' => array_unique($timeArr)));
	} else {
		wp_send_json_error();
	}


	exit;
}

//coupon search ajax
add_action('wp_ajax_gctc_attractioncoupon_search', 'gctc_attractioncoupon_search');
add_action('wp_ajax_nopriv_gctc_attractioncoupon_search', 'gctc_attractioncoupon_search');

function gctc_attractioncoupon_search()
{

	global $wpdb;
	$amount = 0;
	if (isset($_POST['quote_id'])) {
		$quote_id = sanitize_text_field($_POST['quote_id']);
		$total_price = sanitize_text_field($_POST['total_price']);

		update_post_meta($quote_id, '_gctcf_coupon_checked', '');
		if (!empty($_POST['coupon_code_search'])) {
			$discount_type = 'amount';
			$coupon_code = sanitize_text_field($_POST['coupon_code_search']);
			update_post_meta($quote_id, '_gctcf_coupon_checked', $coupon_code);
			$coupon_wp = new WC_Coupon($coupon_code);

			$amount = $coupon_wp->get_amount();
			if (!$amount) {

				$physical_vouchers = get_posts(array(
					'post_type' => 'gc4t_store_voucher',
					'post_status' => 'private',
					'posts_per_page' => 1,
					'meta_query' => array(
						array(
							'key' => 'gc4t_voucher_status',
							'value' => 'active',
						),
						array(
							'key' => 'gc4t_voucher_code',
							'value' => $coupon_code,
						),
					)
				));
				if (isset($physical_vouchers[0])) {
					$amount = get_post_meta($physical_vouchers[0]->ID, 'gc4t_voucher_amount_remaining', true);
					update_post_meta($quote_id, '_gctcf_booking_amount', $total_price);
					update_post_meta($quote_id, '_gctcf_coupon_amount', $amount);
					update_post_meta($quote_id, '_gctcf_coupon_code', $coupon_code);
				} else {
					update_post_meta($quote_id, '_gctcf_booking_amount', $total_price);
					update_post_meta($quote_id, '_gctcf_coupon_amount', '');
					update_post_meta($quote_id, '_gctcf_coupon_code', '');
				}
				$total_price = sanitize_text_field($_POST['total_price']);
				$total_price = ($total_price) ? $total_price : 0;
				if ($total_price) {
					$difference = $total_price - $amount;
					if ($difference < 0) {
						$amount = $total_price - 1;
					}
				}
			}
			if ($discount_type == 'percent') {
				$total_price = sanitize_text_field($_POST['total_price']);
				$total_price = ($total_price) ? $total_price : 0;
				if ($total_price) {
					$discount_amount = $total_price / 100 * $amount;
					$amount = sprintf('%01.2f', $discount_amount);
				}
			}
		}
		echo $amount;
	}
	exit;
}

//hotel load more ajax
add_action('wp_ajax_gctcf_load_more_hotels', 'gctcf_load_more_hotels');
add_action('wp_ajax_nopriv_gctcf_load_more_hotels', 'gctcf_load_more_hotels');

function gctcf_load_more_hotels()
{
	ob_start();
    $offset = isset($_POST['gctcf_offset']) ? $_POST['gctcf_offset'] : 10;
    $gctcf_prices = isset($_POST['gctcf_prices']) ? $_POST['gctcf_prices'] : '';
    $gctcf_ratings = isset($_POST['gctcf_ratings']) ? $_POST['gctcf_ratings'] : '';
    $limit = 100;
    $hotels = isset($_SESSION['gctcf_all']) ? $_SESSION['gctcf_all'] : array();
    $country_code = isset($_POST['country_code']) ? $_POST['country_code'] : '';
    $hotel_name = isset($_POST['hotel_name']) ? $_POST['hotel_name'] : '';
    $hotel_regionid = isset($_POST['hotel_regionid']) ? $_POST['hotel_regionid'] : '';
    $hotel_country_by_region = isset($_POST['hotel_country_by_region']) ? $_POST['hotel_country_by_region'] : '';
    $hotel__region__name = isset($_POST['hotel__region__name']) ? $_POST['hotel__region__name'] : '';
    $hotel_start_date = isset($_POST['hotel_check_in_date']) ? $_POST['hotel_check_in_date'] : '';
    $hotel_night = isset($_POST['hotel_night']) ? $_POST['hotel_night'] : '';
    $rooms_requested = isset($_POST['no_of_room']) ? $_POST['no_of_room'] : array();
    $room_with_adults = isset($_POST['hotel_adults']) ? $_POST['hotel_adults'] : array();
    $room_with_children = isset($_POST['hotel_children']) ? $_POST['hotel_children'] : array();

    $stuba_hotels = isset($_SESSION['stuba_all']) ? $_SESSION['stuba_all'] : array();
    $travelnda_hotels = isset($_SESSION['travelnda_all']) ? $_SESSION['travelnda_all'] : array();

    $next_stuba = array_slice($stuba_hotels, $offset / 2, 50);
    $next_travelnda = array_slice($travelnda_hotels, $offset / 2, 50);

    $hotels = array_merge($next_travelnda, $next_stuba);
    
    if(!empty($hotels))
    {
       // $merged_results = array_slice($hotels, $offset, $limit);
        //pre($merged_results);

        foreach ($hotels as $merged_result): ?>
        
            <div class="gc-row hotel__search_result_view">
                <div class="gc-lg-3">
                    <input type="hidden" name="feed_type" id="feed_type" value="<?php echo $merged_result['feed']; ?>">
                    <input type="hidden" name="hotel__id" id="hotel__id" value="<?php echo $merged_result['hotel_id']; ?>">


                    <div class="property_img">
                        <img src="<?php echo $merged_result['hotel_image']; ?>">
                    </div>
                </div>

                <div class="gc-lg-9">
                <div class="search-result-view-content">
                    <a class="gctcf-search-result-inner"><h3><?php echo $merged_result['hotel_name']; ?></h3>
					<span class="rating">
					<?php 
							for($k=0;$k<$merged_result['star_rating'];$k++)
		                    {
		                        echo '<i class="fa fa-star"></i>';
		                    }
					?>
					</span></a>

                    <div class="hotel-list2">
                        <div class="gc-md-4 mobile-room-type-hedaing">
                            <h6>ROOM TYPES</h6>
                        </div>
                        <div class="gc-md-2 mobile-breakfast-hedaing">
                            <h6>Breakfast</h6>
                        </div>
                        <div class="gc-md-2 mobile-price-hedaing">
                            <h6>PRICE</h6>
                        </div>
                        <div class="gc-md-2 mobile-facility-hedaing">
                            <h6>Facility</h6>
                        </div>
                        <div class="gc-md-2 mobile-action-hedaing">
                            <h6>ACTION</h6>
                        </div>
                    </div>

                    <?php foreach ($merged_result['room_types'] as $room_type_index => $room_type) : ?>
                        <?php //if ($room_type_index < 3) : ?>
                            <div class="gc-md-12 gc-sm-12 gc-xs-12 mobile-border-hotel-search">
                                <form action="<?php echo home_url(); ?>/hotel-booking/" method="post" name="fr3" target="_blank">
                                    <div class="hidden_file">
                                        <input type="hidden" name="feed_type" value="<?php echo $room_type['feed']; ?>">
                                        <input type="hidden" name="hotel_name" value="<?php echo $merged_result['hotel_name']; ?>">
                                        <input type="hidden" name="hotel_id" value="<?php echo $merged_result['hotel_id']; ?>">
                                        <input type="hidden" name="hotel_quote_id" value="<?php echo $room_type['quote_id']; ?>">
                                        <input type="hidden" name="room_code" value="<?php echo $room_type['room_code']; ?>">
                                        <input type="hidden" name="room_name" value="<?php echo $room_type['name']; ?>">
                                        <input type="hidden" name="room_meal" value="<?php echo $room_type['meal']; ?>">
                                        <input type="hidden" name="hotel_start_date" value="<?php echo $hotel_start_date; ?>">
                                        <input type="hidden" name="hotel_nights" value="<?php echo $hotel_night; ?>">
                                        <input type="hidden" name="room_price" value="<?php echo round($room_type['total_price'],2);?>">
                                        <?php foreach ($room_with_adults as $key => $values) : ?>
                                            <input type="hidden" name="numbers_of_adults[<?php echo $key; ?>]" value="<?php echo $values; ?>" />
                                        <?php endforeach; ?>
                                        <?php foreach ($room_with_children as $key => $values): ?>
                                            <input type="hidden" name="numbers_of_child[<?php echo $key; ?>]" value="<?php echo $values; ?>" /> 
                                        <?php endforeach; ?>
                                        <?php foreach ($rooms_requested as $key => $values): ?>
                                            <input type="hidden" name="numbers_of_room[<?php echo $key; ?>]" value="<?php echo $values; ?>" />  
                                        <?php endforeach; ?>
                                    </div>

                                    <div class="gc-md-4 gc-sm-6 gc-xs-12 mobile-roomtype-result">
                                        <p><?php echo $room_type['name']; ?></p>
                                        <input type="hidden" name="room_type_name_by_hotel" value="<?php echo $room_type['name']; ?>">
                                    </div>

                                    <div class="gc-md-2 gc-sm-6 gc-xs-12 mobile-breakfast-result">
                                        <p><?php echo $room_type['meal']; ?></p>
                                    </div>

                                    <div class="gc-md-2 gc-sm-6 gc-xs-12 list-style-hotel1 mobile-price-result">
                                        <h5><?php echo '£'.round($room_type['total_price'],2);?></h5>
                                    </div>

                                    <div class="gc-md-2 gc-sm-6 gc-xs-12 list-style-hotel1 mobile-facility-result">
                                        <button type="button" class="btn btn-primary mobile_bottom_facility pd-md-1" id="hotel__id_ajax_<?php echo $merged_result['hotel_id']; ?>" value="<?php echo $merged_result['hotel_id']; ?>" onclick="hotel_facility_ajax(this.id)" data-feed="<?php echo $merged_result['feed']; ?>" data-toggle="modal" data-target="#product_view" style="height:42px;"><span>Quick </span><span>View</span></button>
                                    </div>

                                    <div class="gc-md-2 gc-sm-6 gc-xs-12 list-style-hotel1 mobile-action-result">
                                        <input type="submit" name="hotel__booking" id="hotel__booking" value="BOOK NOW" class="btn btn-primary border-radius pd-md-1"/>
                                    </div>

                                    <div class="mobile_padding_hotel_search"></div>
                                </form>
                            </div>
                        <?php //endif; ?>
                    <?php endforeach; ?>
                </div>
                </div>
            </div>
        <?php endforeach;
    }

    $html = ob_get_clean();
    echo json_encode( 
    		array('html' =>  $html, 'offset' => ($offset + 100), 'count' => count($_SESSION['gctcf_all']))
    	);
    	exit;
}
