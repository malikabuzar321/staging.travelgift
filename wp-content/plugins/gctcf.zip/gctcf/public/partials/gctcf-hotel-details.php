<?php
$hotel_id = isset($_REQUEST['hotel-id']) ? $_REQUEST['hotel-id'] : 0;

$dir = wp_get_upload_dir();
$url = $dir['baseurl'] . '/hotel_api/' . $hotel_id . '.xml';
?>
<section class="gc-section clearfix">
    <div class="row">
        <?php
        if ($url) :
            $xml_hotel_data = get_hotles($url);
            $avilable_hotel_facility = simplexml_load_string($xml_hotel_data);

            if ($avilable_hotel_facility && isset($avilable_hotel_facility->Name)) :
        ?>
                <h3><?php echo $avilable_hotel_facility->Name; ?></h3>
                <?php if ($avilable_hotel_facility->Photo) : ?>
                    <div class="col-sm-12">
                        <div class="hotel-full-img"><img src="https://api.stuba.com<?php echo $avilable_hotel_facility->Photo[0]->Url; ?>" alt="image"></div>
                        <ul class="gc-hotel-light-box">
                            <?php
                            foreach ($avilable_hotel_facility->Photo as $avilable_hotel_photo) {
                            ?>
                                <li class="hotel-thumb"><img src="https://api.stuba.com<?php echo $avilable_hotel_photo->Url; ?>" alt="image"></li>
                            <?php }  ?>

                        </ul>
                    </div>
                <?php endif; ?>
                <div class="gc-row gc-hotel-addres-row">
                    <div class="gc-col-8">
                        <h5><u>Address</u></h5>

                        <?php
                        echo $avilable_hotel_facility->Address->Address1;
                        if (!empty($avilable_hotel_facility->Address->Address1)) {
                            echo ',' . $avilable_hotel_facility->Address->Address1;
                        }
                        if (!empty($avilable_hotel_facility->Address->Address2)) {
                            echo ',' . $avilable_hotel_facility->Address->Address2;
                        }
                        if (!empty($avilable_hotel_facility->Address->City)) {
                            echo ',' . $avilable_hotel_facility->Address->City;
                        }
                        if (!empty($avilable_hotel_facility->Address->State)) {
                            echo ',' . $avilable_hotel_facility->Address->State;
                        }
                        if (!empty($avilable_hotel_facility->Address->Zip)) {
                            echo ',' . $avilable_hotel_facility->Address->Zip;
                        }
                        if (!empty($avilable_hotel_facility->Address->Country)) {
                            echo ',' . $avilable_hotel_facility->Address->Country;
                        }
                        echo '<br/>';
                        if (!empty($avilable_hotel_facility->Region->Name)) {
                            echo 'Region: ' . $avilable_hotel_facility->Region->Name;
                        }
                        ?>

                    </div>
                    <div class="gc-col-4">
                        <h5><u>Rating</u></h5>
                        <?php
                        if (!empty($avilable_hotel_facility->Stars)) {
                            echo '<span class="rating">';
                            for ($k = 1; $k <= $avilable_hotel_facility->Stars; $k++) {
                                echo '<i class="fa fa-star"></i>';
                            }
                            echo '</span>';
                        }
                        ?>
                    </div>
                </div>

                <div class="gc-col-12 gc-hotel-description-col">
                    <h4>Facility/Description</h4>

                    <?php
                    $i = 1;
                    foreach ($avilable_hotel_facility->Description as $facility_list) {
                        $facility_count++;
                    ?>

                        <div class="gc-hotel-description-inner">
                            <b><?php echo $i; ?>. <?php echo $facility_list->Type; ?>:</b>
                            <p><?php echo $facility_list->Text; ?></p>
                        </div>


                    <?php
                        $i++;
                    }
                    ?>
                </div>
                <div class="gc-md-2 gc-sm-6 gc-xs-12">
                    <?php
                    $hotel_url_args = array(
                        'hotel-region-id' => (string) $avilable_hotel_facility->Region->Id,
                        'hotel-region-name' => (string) $avilable_hotel_facility->Region->Name,
                        'hotel-name' => (string) $avilable_hotel_facility->Name,
                    );
                    $hotel_url = add_query_arg(
                        $hotel_url_args,
                        home_url() . '/hotel-search',
                    );
                    ?>
                    <a href="<?php echo $hotel_url; ?>"><input type="submit" name="booking_details" class="btn btn-primary btn-block" value="Book Now" /></a>

                </div>
            <?php else : ?>
                <div class="gc-col-12 gc-no-hotel">
                    <p>No data found!</p>
                    <a href="<?php echo  home_url('/hotels'); ?>" class="gc-new-hotels">Search Hotels</a>
                </div>
            <?php endif; ?>
        <?php else : ?>
            <div class="gc-col-12 gc-no-hotel">
                <p>No data found!</p>
                <a href="<?php echo  home_url('/hotels'); ?>" class="gc-new-hotels">Search Hotels</a>
            </div>
        <?php endif; ?>
    </div>
</section>