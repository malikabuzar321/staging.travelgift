<?php
//pre($hotel_data);
 $hotel_id=$hotel_data->Id;
 $hotel_name=$hotel_data->Name;
 $hotel_country=$hotel_data->Address->Country;
 $hotel_city=$hotel_data->Address->City;
 $hotel_stars=$hotel_data->Stars;
 $hotel_img=$hotel_data->Photo[0]->Url;
?>

<div class="hotel-item item">
    <div class="hotel-image">
        <a href="<?php echo home_url();?>/hotel-details?hotel-id=<?php echo $hotel_id; ?>">
        <?php if ($hotel_img && strpos($hotel_img, 'photo-not-available') === false) : ?>
            <?php $img_contents = file_get_contents('https://api.stuba.com'.$hotel_img);
            if ($img_contents): ?>
                <img src="<?php echo 'https://api.stuba.com'.$hotel_img; ?>"  data-srcset="<?php echo 'https://api.stuba.com'.$hotel_img; ?>" data-src="<?php echo 'https://api.stuba.com'.$hotel_img; ?>"  alt="Online giftcard for hotel <?=$hotel_name;?>" class="img-responsive lazyload">
            <?php else: ?>
                <img src="<?php echo GCTCF_URL .'public/images/logo@2x.png'; ?>" alt="Online giftcard for hotel <?=$hotel_name;?>">
            <?php endif; ?>
        <?php else: ?>
        <img src="<?php echo GCTCF_URL .'public/images/logo@2x.png'; ?>" alt="Online giftcard for hotel <?=$hotel_name;?>">
        <?php endif; ?>
        </a>
    </div>
    <div class="hotel-contact-inner">
    <div class="hotel-title">
        <h5><a href="#" title=""><?php echo $hotel_name; ?></a></h5>
    </div>
    <div class="rating_and_booknow">
        <span class="rating">
             <?php for($k=1;$k<=$hotel_stars;$k++){ 
                echo '<i class="fa fa-star"></i>';
                 } ?>
        </span>
  
    </div>
    <p ><?php
		 // strip tags to avoid breaking any html
		$hotel_description=$hotel_data->Description->Text;
		$string = strip_tags($hotel_description);
		if (strlen($string) > 150) {
			// truncate string
			$stringCut = substr($string,0,150);
			// make sure it ends in a word so assassinate doesn't become ass...
			$string = nl2br(substr($stringCut, 0, strrpos($stringCut, ' '))); 
		}
		echo $string; ?>
            
    </p>
    <div class="book_now_section">
        <a href="<?php echo home_url();?>/hotel-details?hotel-id=<?php echo $hotel_id; ?>">View Details</a>
    </div>
    </div>
</div>