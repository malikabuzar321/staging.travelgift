<?php

/**
 * Fired during plugin activation
 *
 * @link       https://cmitexperts.com/
 * @since      1.0.0
 *
 * @package    Gctcf
 * @subpackage Gctcf/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Gctcf
 * @subpackage Gctcf/includes
 * @author     CMITEXPERTS TEAM <cmitexperts@gmail.com>
 */
class Gctcf_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
